from django.apps import AppConfig


class DosDetectionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dos_detection_app'
